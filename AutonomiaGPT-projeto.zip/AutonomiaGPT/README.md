# Autonomia GPT — protótipo Android inicial

Este é um projeto-fonte Android (Java) para abrir em um ambiente que compile projetos Gradle/Android. Ele contém:
- interface inicial;
- chamada de texto à OpenAI Responses API (`gpt-4.1-mini`);
- serviço de acessibilidade com funções de toque, deslize e preenchimento de campo;
- botão para abrir as configurações de acessibilidade.

## Limites importantes desta versão
Esta versão **não é ainda o agente autônomo completo**: não captura a tela para enviar ao modelo, não tem ciclo de planejamento visual e o botão de ciclo experimental não executa ações automáticas. Isso é intencional: o próximo módulo deve implementar captura via MediaProjection, formato estruturado de ações, limites de execução e parada imediata antes de habilitar controle autônomo.

## Segurança
- Não coloque sua chave de API em código-fonte, repositório público ou APK compartilhado. Nesta versão ela é digitada na tela e usada durante a execução.
- A API pode gerar custos. Configure limites de uso no painel da OpenAI.
- Ative acessibilidade somente para seu próprio aplicativo e mantenha o botão de parada acessível.
- Não automatize pagamentos, compras, envio de mensagens ou publicação sem confirmação explícita.

## Requisitos de build
- Android SDK 35
- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1

Abra a pasta raiz como projeto Gradle em um ambiente Android compatível e compile o módulo `app`.

## Compilar sem instalar IDE no celular (GitHub Actions)
1. Crie um repositório privado no GitHub.
2. Envie todos os arquivos desta pasta para o repositório (incluindo a pasta `.github`).
3. Abra a aba **Actions** e execute **Build Android APK** com **Run workflow** (ou faça um commit na branch `main`).
4. Quando terminar, abra a execução e baixe o artefato `AutonomiaGPT-debug-apk`.
5. Extraia o ZIP do artefato e instale `app-debug.apk`. O Android pode pedir autorização para instalar apps dessa fonte.

Não coloque a chave da OpenAI no repositório. Digite-a somente no aplicativo instalado.
