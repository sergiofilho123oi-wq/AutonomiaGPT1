package com.sergio.autonomia;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private EditText apiKey, mission;
    private TextView status, reply;
    private Button runButton, stopButton;
    private volatile boolean running = false;
    private Thread worker;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().setStatusBarColor(Color.rgb(3,5,10));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(18)); root.setBackgroundColor(Color.rgb(3,5,10));
        ScrollView scroll = new ScrollView(this); scroll.addView(root);
        TextView title = text("AUTONOMIA GPT", 27, Color.rgb(0,217,255)); title.setTypeface(null, 1); root.addView(title);
        TextView subtitle = text("Protótipo inicial • controle autorizado", 14, Color.LTGRAY); root.addView(subtitle);
        root.addView(gap(18));
        root.addView(text("Chave da API OpenAI", 15, Color.WHITE));
        apiKey = new EditText(this); apiKey.setSingleLine(true); apiKey.setHint("Cole sua chave sk-..."); apiKey.setHintTextColor(Color.GRAY); apiKey.setTextColor(Color.WHITE); apiKey.setInputType(129); apiKey.setBackgroundColor(Color.rgb(20,25,35)); root.addView(apiKey, params());
        TextView warning = text("A chave fica apenas nesta tela durante a execução. Não compartilhe o APK com uma chave embutida.", 12, Color.rgb(255,190,100)); root.addView(warning);
        root.addView(gap(12)); root.addView(text("Missão", 15, Color.WHITE));
        mission = new EditText(this); mission.setMinLines(2); mission.setGravity(48); mission.setHint("Ex.: explique o que devo fazer no aplicativo aberto"); mission.setHintTextColor(Color.GRAY); mission.setTextColor(Color.WHITE); mission.setBackgroundColor(Color.rgb(20,25,35)); root.addView(mission, params());
        root.addView(gap(12));
        Button accessibility = button("1 • Ativar acessibilidade"); root.addView(accessibility, params());
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button test = button("2 • Testar conexão com GPT"); root.addView(test, params());
        test.setOnClickListener(v -> askGPT());
        runButton = button("3 • Iniciar ciclo de ações (experimental)"); root.addView(runButton, params());
        stopButton = button("PARAR", Color.rgb(150,35,45)); root.addView(stopButton, params());
        status = text("Estado: aguardando", 14, Color.rgb(180,220,230)); root.addView(status);
        reply = text("A resposta da IA aparecerá aqui.", 14, Color.WHITE); root.addView(reply);
        TextView note = text("Este primeiro protótipo envia a missão à API. Ainda não captura a tela nem executa um agente visual completo. O controle por acessibilidade só funciona após você ativar o serviço nas Configurações.", 12, Color.LTGRAY); root.addView(note);
        runButton.setOnClickListener(v -> startLoop()); stopButton.setOnClickListener(v -> { running = false; status.setText("Estado: parada solicitada"); });
        setContentView(scroll);
    }

    private void askGPT() {
        String key = apiKey.getText().toString().trim(); String task = mission.getText().toString().trim();
        if (key.isEmpty() || task.isEmpty()) { status.setText("Preencha a chave e a missão."); return; }
        status.setText("Estado: consultando o GPT...");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject(); body.put("model", "gpt-4.1-mini");
                JSONArray input = new JSONArray(); JSONObject msg = new JSONObject(); msg.put("role", "user");
                JSONArray content = new JSONArray(); JSONObject c = new JSONObject(); c.put("type", "input_text"); c.put("text", "Você é o cérebro de um assistente Android. Por enquanto, NÃO afirme que consegue ver a tela. Responda em português e explique um plano seguro e curto para esta missão: " + task); content.put(c); msg.put("content", content); input.put(msg); body.put("input", input);
                HttpURLConnection conn = (HttpURLConnection) new URL("https://api.openai.com/v1/responses").openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(30000); conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer " + key); conn.setRequestProperty("Content-Type", "application/json");
                try (OutputStream os = conn.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                int code = conn.getResponseCode(); java.io.InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                java.util.Scanner scanner = new java.util.Scanner(stream, "UTF-8").useDelimiter("\\A"); String raw = scanner.hasNext() ? scanner.next() : ""; scanner.close();
                if (code < 200 || code >= 300) throw new Exception("API HTTP " + code + ": " + raw);
                JSONObject json = new JSONObject(raw); String output = extractText(json);
                runOnUiThread(() -> { status.setText("Estado: resposta recebida"); reply.setText(output); });
            } catch (Exception e) { runOnUiThread(() -> status.setText("Erro: " + e.getMessage())); }
        }).start();
    }

    private String extractText(JSONObject json) {
        try {
            JSONArray out = json.getJSONArray("output"); StringBuilder sb = new StringBuilder();
            for (int i=0;i<out.length();i++) { JSONObject item=out.getJSONObject(i); JSONArray content=item.optJSONArray("content"); if(content==null) continue;
                for(int j=0;j<content.length();j++){ JSONObject part=content.getJSONObject(j); if("output_text".equals(part.optString("type"))) { if(sb.length()>0) sb.append("\n"); sb.append(part.optString("text")); } }
            }
            return sb.length()==0 ? json.toString() : sb.toString();
        } catch(Exception e) { return json.toString(); }
    }

    private void startLoop() {
        if (running) return;
        if (apiKey.getText().toString().trim().isEmpty() || mission.getText().toString().trim().isEmpty()) { status.setText("Preencha a chave e a missão primeiro."); return; }
        AutomationAccessibilityService service = AutomationAccessibilityService.getInstance();
        if (service == null) { status.setText("Ative o serviço de acessibilidade nas Configurações primeiro."); startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
        // Safety-first MVP: do not execute AI-generated actions until screen capture and a validated action protocol are implemented.
        running = true; status.setText("Modo experimental iniciado. Nenhum toque automático será feito nesta versão.");
        reply.setText("Próxima etapa: integrar captura de tela autorizada e ações estruturadas com validação antes de permitir autonomia real. Use PARAR para encerrar este modo.");
    }
    private TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0, dp(5), 0, dp(5)); return t; }
    private Button button(String s) { return button(s, Color.rgb(0,100,135)); }
    private Button button(String s, int color) { Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); return b; }
    private View gap(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return v; }
    private LinearLayout.LayoutParams params() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
